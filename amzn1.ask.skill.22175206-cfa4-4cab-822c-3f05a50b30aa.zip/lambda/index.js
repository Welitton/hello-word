/* *
 * This sample demonstrates handling intents from an Alexa skill using the Alexa Skills Kit SDK (v2).
 * Please visit https://alexa.design/cookbook for additional examples on implementing slots, dialog management,
 * session persistence, api calls, and more.
 * */
const Alexa = require('ask-sdk-core');
const persistenceAdapter = require('ask-sdk-s3-persistence-adapter');

const LaunchRequestHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'LaunchRequest';
    },
    handle(handlerInput) {
        const speakOutput = 'Seja bem-vindo vindo ao seu centro de Organização Financeira. O que posso fazer por você?';
        const repromptText = 'Estou aqui para te ajudar a Organizar suas Finanças. Por onde deseja começar?';
        
        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(repromptText)
            .getResponse();
    }
};

const CadastrarMetasHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'HelloWorldIntent';
    },
    async handle(handlerInput) {
        const metanome = handlerInput.requestEnvelope.request.intent.slots.metanome.value;
        const metavalor = handlerInput.requestEnvelope.request.intent.slots.metavalor.value;
        const metadata = handlerInput.requestEnvelope.request.intent.slots.metadata.value;
        
        const attributesManager = handlerInput.attributesManager;
        const metasAttributes = {
        "metanome" : metanome,
        "metavalor" : metavalor,
        "metadata" : metadata
        };
        attributesManager.setPersistentAttributes(metasAttributes);
        await attributesManager.savePersistentAttributes();


        const speakOutput = 'Hello World!';

        return handlerInput.responseBuilder
            .speak(speakOutput)
            //.reprompt('add a reprompt if you want to keep the session open for the user to respond')
            .getResponse();
    }
};

const CadastrarDespesasHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'HelloWorldIntent';
    },
    async handle(handlerInput) {
        const depesanome = handlerInput.requestEnvelope.request.intent.slots.despesanome.value;
        const despesavalor = handlerInput.requestEnvelope.request.intent.slots.despesavalor.value;
        const despesavencimento = handlerInput.requestEnvelope.request.intent.slots.despesavencimento.value;
        
        const attributesManager = handlerInput.attributesManager;
        const despesasAttributes = {
        "despesanome" : depesanome,
        "despesavalor" : despesavalor,
        "despesavencimento" : despesavencimento
        };
        attributesManager.setPersistentAttributes(despesasAttributes);
        await attributesManager.savePersistentAttributes();

        const speakOutput = 'Hello World!';

        return handlerInput.responseBuilder
            .speak(speakOutput)
            //.reprompt('add a reprompt if you want to keep the session open for the user to respond')
            .getResponse();
    }
};

const CadastrarRendasHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'HelloWorldIntent';
    },
    async handle(handlerInput) {
        const rendanome = handlerInput.requestEnvelope.request.intent.slots.rendanome.value;
        const rendavalor = handlerInput.requestEnvelope.request.intent.slots.rendavalor.value;
        const rendaperiodo = handlerInput.requestEnvelope.request.intent.slots.rendaperiodo.value;
        
        const attributesManager = handlerInput.attributesManager;
        const metasAttributes = {
        "rendanome" : rendanome,
        "rendavalor" : rendavalor,
        "rendaperiodo" : rendaperiodo
        };
        attributesManager.setPersistentAttributes(metasAttributes);
        await attributesManager.savePersistentAttributes();


        const speakOutput = 'Hello World!';

        return handlerInput.responseBuilder
            .speak(speakOutput)
            //.reprompt('add a reprompt if you want to keep the session open for the user to respond')
            .getResponse();
    }
};

const CadastrarInvestimentosHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'HelloWorldIntent';
    },
    async handle(handlerInput) {
        const investimentonome = handlerInput.requestEnvelope.request.intent.slots.investimentonome.value;
        const investimentoinicial = handlerInput.requestEnvelope.request.intent.slots.investimentoinicial.value;
        const investimentorentabilidade = handlerInput.requestEnvelope.request.intent.slots.investimentorentabilidade.value;
        const investimentoperiodicidade = handlerInput.requestEnvelope.request.intent.slots.investimentoperiodicidade.value;
        const investimentodata = handlerInput.requestEnvelope.request.intent.slots.investimentodata.value;

        const attributesManager = handlerInput.attributesManager;
        const metasAttributes = {
        "investimentonome" : investimentonome,
        "investimentorentabilidade" : investimentorentabilidade,
        "investimentoinicial" : investimentoinicial,
        "investimentoperiodicidade" : investimentoperiodicidade,
        "investimentodata" : investimentodata,
        };
        attributesManager.setPersistentAttributes(metasAttributes);
        await attributesManager.savePersistentAttributes();


        const speakOutput = 'Hello World!';

        return handlerInput.responseBuilder
            .speak(speakOutput)
            //.reprompt('add a reprompt if you want to keep the session open for the user to respond')
            .getResponse();
    }
};

const CadastrarLembreteFinanceiroHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'HelloWorldIntent';
    },
    async handle(handlerInput) {
        const lembretenome = handlerInput.requestEnvelope.request.intent.slots.lembretenome.value;
        const lembretedata = handlerInput.requestEnvelope.request.intent.slots.lembretedata.value;
        const lembreteperiodo = handlerInput.requestEnvelope.request.intent.slots.lembreteperiodo.value;
        
        const attributesManager = handlerInput.attributesManager;
        const metasAttributes = {
        "lembretenome" : lembretenome,
        "lembretedata" : lembretedata,
        "lembreteperiodo," : lembreteperiodo
        };
        attributesManager.setPersistentAttributes(metasAttributes);
        await attributesManager.savePersistentAttributes();


        const speakOutput = 'Hello World!';

        return handlerInput.responseBuilder
            .speak(speakOutput)
            //.reprompt('add a reprompt if you want to keep the session open for the user to respond')
            .getResponse();
    }
};

const HelpIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'CadastrarMetas';
    },
    handle(handlerInput) {
        const speakOutput = 'Perfeito, sua nova meta é $ {meta.nome} de valor $ {meta.valor} e prazo de até {meta.data}.';

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};

const CancelAndStopIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && (Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.CancelIntent'
                || Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.StopIntent');
    },
    handle(handlerInput) {
        const speakOutput = 'Goodbye!';

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .getResponse();
    }
};
/* *
 * FallbackIntent triggers when a customer says something that doesn’t map to any intents in your skill
 * It must also be defined in the language model (if the locale supports it)
 * This handler can be safely added but will be ingnored in locales that do not support it yet 
 * */
const FallbackIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.FallbackIntent';
    },
    handle(handlerInput) {
        const speakOutput = 'Sorry, I don\'t know about that. Please try again.';

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};
/* *
 * SessionEndedRequest notifies that a session was ended. This handler will be triggered when a currently open 
 * session is closed for one of the following reasons: 1) The user says "exit" or "quit". 2) The user does not 
 * respond or says something that does not match an intent defined in your voice model. 3) An error occurs 
 * */
const SessionEndedRequestHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'SessionEndedRequest';
    },
    handle(handlerInput) {
        console.log(`~~~~ Session ended: ${JSON.stringify(handlerInput.requestEnvelope)}`);
        // Any cleanup logic goes here.
        return handlerInput.responseBuilder.getResponse(); // notice we send an empty response
    }
};
/* *
 * The intent reflector is used for interaction model testing and debugging.
 * It will simply repeat the intent the user said. You can create custom handlers for your intents 
 * by defining them above, then also adding them to the request handler chain below 
 * */
const IntentReflectorHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest';
    },
    handle(handlerInput) {
        const intentName = Alexa.getIntentName(handlerInput.requestEnvelope);
        const speakOutput = `You just triggered ${intentName}`;

        return handlerInput.responseBuilder
            .speak(speakOutput)
            //.reprompt('add a reprompt if you want to keep the session open for the user to respond')
            .getResponse();
    }
};
/**
 * Generic error handling to capture any syntax or routing errors. If you receive an error
 * stating the request handler chain is not found, you have not implemented a handler for
 * the intent being invoked or included it in the skill builder below 
 * */
const ErrorHandler = {
    canHandle() {
        return true;
    },
    handle(handlerInput, error) {
        const speakOutput = 'Sorry, I had trouble doing what you asked. Please try again.';
        console.log(`~~~~ Error handled: ${JSON.stringify(error)}`);

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};

const LoadMetasInterceptor = {
    async process(handlerInput) {
        const attributesManager = handlerInput.attributesManager;
        const sessionAttributes = await attributesManager.getPersistentAttributes() || {};

        const year = sessionAttributes.hasOwnProperty('year') ? sessionAttributes.year : 0;
        const month = sessionAttributes.hasOwnProperty('month') ? sessionAttributes.month : 0;
        const day = sessionAttributes.hasOwnProperty('day') ? sessionAttributes.day : 0;

        if (year && month && day) {
            attributesManager.setSessionAttributes(sessionAttributes);
        }
    }
};

const LoadDespesasInterceptor = {
    async process(handlerInput) {
        const attributesManager = handlerInput.attributesManager;
        const sessionAttributes = await attributesManager.getPersistentAttributes() || {};

        const year = sessionAttributes.hasOwnProperty('year') ? sessionAttributes.year : 0;
        const month = sessionAttributes.hasOwnProperty('month') ? sessionAttributes.month : 0;
        const day = sessionAttributes.hasOwnProperty('day') ? sessionAttributes.day : 0;

        if (year && month && day) {
            attributesManager.setSessionAttributes(sessionAttributes);
        }
    }
};
/**
 * This handler acts as the entry point for your skill, routing all request and response
 * payloads to the handlers above. Make sure any new handlers or interceptors you've
 * defined are included below. The order matters - they're processed top to bottom 
 * */
exports.handler = Alexa.SkillBuilders.custom()
.withPersistenceAdapter(
new persistenceAdapter.S3PersistenceAdapter({bucketName:process.env.S3_PERSISTENCE_BUCKET})
)
    .addRequestHandlers(
        HasCadastrarMetasLaunchRequestHandler,
        HasCadastrarDespesasLaunchRequestHandler,
        LaunchRequestHandler,
        CadastrarMetasHandler,
        HelpIntentHandler,
        CancelAndStopIntentHandler,
        FallbackIntentHandler,
        SessionEndedRequestHandler,
        IntentReflectorHandler)
    .addRequestInterceptors(
    LoadMetasInterceptor
)
.addRequestInterceptors(
    LoadDespesasInterceptor
)
.addErrorHandlers(
        ErrorHandler)
    .withCustomUserAgent('sample/hello-world/v1.2')
    .lambda();